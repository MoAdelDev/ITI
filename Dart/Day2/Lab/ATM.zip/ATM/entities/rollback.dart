
import 'account.dart';

abstract class RollBack{
  void cancelTransaction(Account account);
}

