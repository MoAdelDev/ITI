export class User{
    constructor(first){

    }
}