function addTwoNumbers(a, b) {
    return a + b;
}

function multiplyTwoNumbers(a, b) {
    return a * b;
}

